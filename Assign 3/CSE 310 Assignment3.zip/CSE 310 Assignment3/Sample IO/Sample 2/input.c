int main(){
	int a[2],c,i,j ; float d;
	d=3.14159;
	a[0]=1;
	a[1]=5;
	for(i=0;i<2;i=i+1){
		if(i==0)
			a[0]=8+i;
		else
			a[1]=7*i;
	}
	c=2;
	i=c* 5 % (1 < 3 && 9);
	j=10; 
	return 0;
}
