int main(){
	d=5;
	int c[3]
	return 0;
}
