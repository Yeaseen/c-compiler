void foo(){
	bar();
}
int v();

int bar(int a, int b){
	return 1;
}

int f(int x);

int a;

int main(){
        bar(1,5);
        bar(1.2,7);
        bar(a,0);
	bar(1);
	bar(1.2,3);
	a(2);
        
	return 0;
}
